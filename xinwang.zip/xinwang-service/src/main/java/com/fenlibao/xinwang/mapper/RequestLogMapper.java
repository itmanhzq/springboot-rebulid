package com.fenlibao.xinwang.mapper;

import com.fenlibao.xinwang.common.BaseMapper;
import com.fenlibao.xinwang.request.RequestLog;
import org.springframework.stereotype.Repository;

/**
 * @author Flynn
 */
@Repository
public interface RequestLogMapper extends BaseMapper<RequestLog> {


}